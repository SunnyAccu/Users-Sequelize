'use strict';
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('ModelNames', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      name: {
        type: Sequelize.STRING
      },
      surname: {
        type: Sequelize.STRING
      },
      phone: {
        type: Sequelize.STRING,
        allowNull: false,
        validate: {
          notNull: { args: true, msg: "You must enter Phone Number" },
          len: { args: [11,11], msg: 'Phone Number is invalid' },
          isInt: { args: true, msg: "You must enter Phone Number" },
        }
      },

      div:{
        type: Sequelize.STRING
      },
      email:{
        type:DataTypes.STRING,
        unique:true,
        allowNull: false
    },
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('ModelNames');
  }
};