const express = require("express");
const {sequelize, User, Post} = require('./../models'); // import models

const app = express(); // create a new express app
app.use(express.json());

app.get('/', function (req, res) {
    res.send('App running')
})

app.post("/users", async(req,res) =>{
    const { name, middle,surname,phone,div,email} = req.body
    try{
        const user = await User.create({name, middle, surname,phone,div,email});
        return res.json(user);
    }catch(err){
        return res.status(500).json(err);
    }
});

app.get("/users", async(req,res) =>{
    try{
        const users = await User.findAll();
        return res.json(users);
    }catch(err){
        return res.status(500).json({err: "An error occured"});
    }
});


app.put("/users/:id", async(req,res) =>{
    const id = req.params.id;
    const { name, middle, surname} = req.body;
    try{
        const user = await User.findOne({
            where: {id}
        });
        user.name = name;
        user.middle = middle;
        user.surname = surname;

        await user.save();
        return res.json(user);

    }catch(err){
        return res.status(500).json({err: "An error occured"});
    }
});

app.delete("/users/:id", async(req,res) =>{
    const id = req.params.id;
    try{
        const user = await User.findOne({
            where: {id}
        });
        await user.destroy();
        return res.json({message: "User Deleted"});
    }catch(err){
        return res.status(500).json({err: "An error occured"});
    }
});


app.listen({port: 5005}, async() =>{
    await sequelize.authenticate()
});